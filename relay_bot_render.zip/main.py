from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
import logging

API_TOKEN = '8072861623:AAEs974ouajgqKm5Ce3mSJUbw20LZgPNd4w'
ADMIN_ID = 6275874409  # آیدی عددی شما

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(lambda message: message.chat.type == 'private')
async def handle_user_message(message: Message):
    forward_text = f"پیام از @{message.from_user.username or 'بی‌نام'} ({message.from_user.id}):\n{message.text}"
    await bot.send_message(ADMIN_ID, forward_text)
    await message.reply("پیامت رسید، به زودی جواب می‌گیری.")

@dp.message_handler(lambda message: message.chat.id == ADMIN_ID, content_types=types.ContentTypes.TEXT)
async def handle_admin_reply(message: Message):
    if message.reply_to_message:
        try:
            user_id_line = message.reply_to_message.text.split('(')[-1].split(')')[0]
            user_id = int(user_id_line)
            await bot.send_message(user_id, message.text)
        except Exception as e:
            await message.reply("خطا در ارسال پیام: آیدی کاربر پیدا نشد.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)